import { redirect } from "next/navigation";

export default function AssessmentIndexPage() {
  redirect("/assessment/1");
}

